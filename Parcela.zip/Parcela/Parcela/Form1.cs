﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace Parcela
{
    public partial class Form1 : Form
    {
        Form2 form2 = new Form2();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || textBox2.Text == "")
            {
                label3.Text = "Obavezna su sva polja za unos!";
            }
            else {
                dbconnection(textBox1.Text, textBox2.Text);
            }
            
        }

        private void dbconnection(String username, String password) {
            string str = "datasource=localhost; username=root; password=; database=parcela";
            MySqlConnection sqlconnection = new MySqlConnection(str);

            try
            {
                sqlconnection.Open();
                
                
            }
            catch { }
            int i = 0;
            
            MySqlCommand cmd = sqlconnection.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from user where username='" + username + "' and password='" + password+"'";
            cmd.ExecuteNonQuery();
            DataTable dt = new DataTable();
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            da.Fill(dt);
            i = Convert.ToInt32(dt.Rows.Count.ToString());

            if (i != 0)
            {
                this.Hide();
                form2.Closed += (s, args) => this.Close();
                form2.Show();
            }
            else { label3.Text = "Neispravan username ili password!"; }

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
