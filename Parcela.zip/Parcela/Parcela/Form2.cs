﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Parcela
{
    public partial class Form2 : Form
    {
        Form3 form3 = new Form3();
        public Form2()
        {
            InitializeComponent();
            
        }

        private void textBox7_Enter(object sender, EventArgs e)
        {
            if (textBox7.Text == "(vrijeme sadnje, vrijeme okopavanja, vrijeme prihrane, vrijeme rezidbe, tretiranje, prinosi)") {
                textBox7.Text = "";
                textBox7.ForeColor = Color.Black;
            }
        }

        private void textBox7_Leave(object sender, EventArgs e)
        {
            if (textBox7.Text == "") {
                textBox7.Text = "(vrijeme sadnje, vrijeme okopavanja, vrijeme prihrane, vrijeme rezidbe, tretiranje, prinosi)";
                textBox7.ForeColor = Color.Gray;
            }
        }

        private void textBox8_Enter(object sender, EventArgs e)
        {
            if (textBox8.Text == "(godina/sezone, kulture, parcele, korištena zaštitna sredstva)")
            {
                textBox8.Text = "";
                textBox8.ForeColor = Color.Black;
            }
        }

        private void textBox8_Leave(object sender, EventArgs e)
        {
            if (textBox8.Text == "")
            {
                textBox8.Text = "(godina/sezone, kulture, parcele, korištena zaštitna sredstva)";
                textBox8.ForeColor = Color.Gray;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            form3.Closed += (s, args) => this.Close();
            form3.Show();
        }
    }
}
